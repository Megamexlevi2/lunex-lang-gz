# ntl-github

  GitHub API client for the NTL language. Install and use it directly in your NTL projects.

  ## Installation

  ```sh
  ntl add (not yet)
  ```

  Or add to your `ntl.mod`:

  ```
  [dependencies]
  ntl-github = "github.com/david-dev/ntl-github@main"
  ```

  ## Usage

  ```ntl
  use "ntl-github"

  val gh = ntl_github.create("your_github_token")

  val repo = gh.getRepo("octocat", "Hello-World")
  io.log(repo.description)

  val issues = gh.listIssues("octocat", "Hello-World")
  each issue in issues {
    io.log(issue.number + ": " + issue.title)
  }

  gh.createIssue("myuser", "myrepo", "Bug: something broke", "Details here", ["bug"])
  ```

  ## API Reference

  ### gh.getRepo(owner, repo)

  Get repository metadata.

  ### gh.listRepos(user?)

  List repositories. Without `user`, lists your own repos (requires token).

  ### gh.createRepo(name, options?)

  Create a new repository.

  Options: `{ description, private, autoInit }`

  ### gh.deleteRepo(owner, repo)

  Delete a repository.

  ### gh.listIssues(owner, repo, state?)

  List issues. `state` is `"open"` (default), `"closed"`, or `"all"`.

  ### gh.getIssue(owner, repo, number)

  Get a specific issue.

  ### gh.createIssue(owner, repo, title, body?, labels?)

  Create a new issue.

  ### gh.closeIssue(owner, repo, number)

  Close an issue.

  ### gh.listPRs(owner, repo, state?)

  List pull requests.

  ### gh.getPR(owner, repo, number)

  Get a specific pull request.

  ### gh.listCommits(owner, repo, branch?)

  List commits on a branch.

  ### gh.getBranches(owner, repo)

  List all branches.

  ### gh.getContents(owner, repo, path, ref?)

  Get file contents (base64-encoded).

  ### gh.getUser(username?)

  Get a user profile. Without `username`, returns your own profile.

  ### gh.listStarred(user?)

  List starred repositories.

  ### gh.starRepo(owner, repo)

  Star a repository.

  ### gh.unstarRepo(owner, repo)

  Unstar a repository.

  ### gh.listReleases(owner, repo)

  List all releases.

  ### gh.getLatestRelease(owner, repo)

  Get the latest release.

  ### gh.createRelease(owner, repo, tag, options?)

  Create a release. Options: `{ name, body, draft, prerelease }`

  ### gh.search(query, type?, options?)

  Search GitHub. `type` is `"repositories"` (default), `"issues"`, `"users"`, etc.

  ### gh.listGists(user?)

  List gists.

  ### gh.createGist(description, files, public?)

  Create a gist. `files` is an object like `{ "file.txt": { content: "..." } }`.

  ### gh.getNotifications()

  Get your unread notifications (requires token).

  ### gh.listFollowers(user?)

  List followers.

  ### gh.listFollowing(user?)

  List accounts the user is following.

  ## Examples

  ```ntl
  use "ntl-github"

  val gh = ntl_github.create(env.get("GITHUB_TOKEN"))

  val me = gh.getUser()
  io.log("Logged in as: " + me.login)

  val results = gh.search("ntl language", "repositories")
  each r in results.items {
    io.log(r.full_name + " - " + r.stargazers_count + " stars")
  }
  ```

  ## License

  GPL-3.0
  