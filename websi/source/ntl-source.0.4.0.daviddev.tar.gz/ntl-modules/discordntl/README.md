# discordntl

A Discord bot library for the [NTL](https://github.com/NTL) scripting language. Provides a full Discord Gateway (WebSocket) client, REST API wrapper, slash command router, and UI component builders.

---

## Installation

Place the `discordntl/` folder in your project or in the NTL module search path, then import it:

```ntl
use "discordntl"
```

---

## File Structure

| File             | Purpose                                              |
|------------------|------------------------------------------------------|
| `index.ntl`      | Main entry point — `create()` and module exports     |
| `constants.ntl`  | All Discord enums (INTENTS, OPCODES, CHANNEL_TYPES…) |
| `rest.ntl`       | Internal HTTP REST helper (`makeRequest`)            |
| `builders.ntl`   | Embed, button, select menu, text input builders      |
| `router.ntl`     | Slash command / component / modal router             |

---

## Quick Start

```ntl
use "discordntl"
use env
use io

val bot = discordntl.create(env.get("DISCORD_TOKEN"))

bot.on("READY", fn(data) {
  io.log("Logged in as " + data.user.username)
})

bot.on("MESSAGE_CREATE", fn(msg) {
  if msg.author.bot !== undefined and msg.author.bot { return }
  if msg.content === "!ping" {
    bot.reply(msg, "Pong!")
  }
})

bot.connect()
```

---

## API Reference

### `discordntl.create(token, options?)`

Creates a new bot client. Returns a bot object with all methods below.

| Parameter        | Type   | Description                               |
|------------------|--------|-------------------------------------------|
| `token`          | string | Your Discord bot token                    |
| `options.intents`| number | Gateway intents bitmask (default: guilds + guildMessages + messageContent) |

---

### Connection

#### `bot.connect()`
Opens the Discord Gateway WebSocket connection. Handles heartbeating, identification, reconnects, and session resumption automatically.

#### `bot.disconnect()`
Closes the WebSocket connection.

---

### Events

#### `bot.on(event, handler)`
Subscribe to a Gateway event. `event` is case-insensitive.

```ntl
bot.on("MESSAGE_CREATE", fn(msg) { ... })
bot.on("READY", fn(data) { ... })
bot.on("GUILD_MEMBER_ADD", fn(member) { ... })
```

Common events: `READY`, `MESSAGE_CREATE`, `MESSAGE_UPDATE`, `MESSAGE_DELETE`, `INTERACTION_CREATE`, `GUILD_MEMBER_ADD`, `GUILD_MEMBER_REMOVE`, `DISCONNECT`, `ERROR`, `HEARTBEAT_ACK`.

#### `bot.off(event, handler?)`
Unsubscribe from an event. If `handler` is omitted, removes all handlers for that event.

#### `bot.once(event, handler)`
Subscribe to an event for a single firing only.

---

### Messages

#### `bot.send(channelId, content, options?)`
Send a message to a channel.

```ntl
bot.send("123456789", "Hello!")

bot.send("123456789", "Hello!", {
  embed: { title: "My Embed", description: "Content", color: 0x5865F2 },
  components: [ bot.actionRow([ bot.button({ label: "Click", customId: "btn1" }) ]) ]
})
```

| Option       | Type    | Description                         |
|--------------|---------|-------------------------------------|
| `embed`      | object  | Embed object (see Embeds section)   |
| `embeds`     | array   | Multiple embeds                     |
| `tts`        | boolean | Text-to-speech                      |
| `reply`      | string  | Message ID to reply to              |
| `components` | array   | Action rows with components         |

#### `bot.reply(message, content, options?)`
Reply to a message object (uses `message.id` and `message.channel_id`).

#### `bot.editMessage(channelId, messageId, content, options?)`
Edit an existing message.

#### `bot.deleteMessage(channelId, messageId)`
Delete a message.

#### `bot.getMessage(channelId, messageId)`
Fetch a single message. Returns the message object or `null`.

#### `bot.getMessages(channelId, options?)`
Fetch multiple messages.

| Option   | Type   | Description                       |
|----------|--------|-----------------------------------|
| `limit`  | number | Max messages to fetch (default 50)|
| `before` | string | Fetch messages before this ID     |
| `after`  | string | Fetch messages after this ID      |

#### `bot.react(channelId, messageId, emoji)`
Add a reaction. Use Unicode emoji or `name:id` format.

#### `bot.removeReaction(channelId, messageId, emoji, userId?)`
Remove a reaction. If `userId` is omitted, removes the bot's own reaction.

#### `bot.pinMessage(channelId, messageId)`
Pin a message.

#### `bot.unpinMessage(channelId, messageId)`
Unpin a message.

#### `bot.startTyping(channelId)`
Trigger the typing indicator in a channel.

---

### Channels

#### `bot.getChannel(channelId)`
Fetch a channel object.

#### `bot.editChannel(channelId, options)`
Edit a channel. `options` follows the [Discord channel modify object](https://discord.com/developers/docs/resources/channel#modify-channel).

#### `bot.deleteChannel(channelId)`
Delete a channel.

#### `bot.createChannel(guildId, options)`
Create a channel in a guild.

---

### Guilds

#### `bot.getGuild(guildId)`
Fetch a guild object.

#### `bot.getGuilds()`
Fetch all guilds the bot is in.

#### `bot.getGuildChannels(guildId)`
Fetch all channels in a guild.

#### `bot.getGuildMembers(guildId, limit?)`
Fetch guild members (default limit: 100).

#### `bot.getMember(guildId, userId)`
Fetch a specific guild member.

#### `bot.kickMember(guildId, userId)`
Kick a member from a guild.

#### `bot.banMember(guildId, userId, options?)`
Ban a member.

| Option                | Type   | Description                              |
|-----------------------|--------|------------------------------------------|
| `deleteMessageSeconds`| number | Seconds of messages to delete (max 604800)|

#### `bot.unbanMember(guildId, userId)`
Remove a ban.

#### `bot.addRole(guildId, userId, roleId)`
Add a role to a member.

#### `bot.removeRole(guildId, userId, roleId)`
Remove a role from a member.

#### `bot.getGuildRoles(guildId)`
Fetch all roles in a guild.

#### `bot.createRole(guildId, options)`
Create a role.

#### `bot.deleteRole(guildId, roleId)`
Delete a role.

---

### Users & DMs

#### `bot.getUser(userId?)`
Fetch a user. If `userId` is omitted, returns the bot's own user object.

#### `bot.getDM(userId)`
Open (or retrieve) a DM channel with a user. Returns the channel object.

#### `bot.sendDM(userId, content, options?)`
Send a direct message to a user. Combines `getDM` + `send`.

---

### Invites

#### `bot.getInvite(code)`
Fetch an invite by its code.

#### `bot.deleteInvite(code)`
Delete an invite.

---

### Presence

#### `bot.setPresence(status, activity?)`
Update the bot's presence.

```ntl
bot.setPresence("online", { name: "!help", type: 2 })
```

| `status` values | Description  |
|-----------------|--------------|
| `"online"`      | Online       |
| `"idle"`        | Idle         |
| `"dnd"`         | Do Not Disturb|
| `"invisible"`   | Invisible    |

| `activity.type` | Description  |
|-----------------|--------------|
| `0`             | Playing      |
| `1`             | Streaming    |
| `2`             | Listening    |
| `3`             | Watching     |
| `5`             | Competing    |

---

### Slash Commands

#### `bot.registerCommand(guildId, command)`
Register a slash command. Pass `null` for `guildId` to register globally.

```ntl
bot.registerCommand("GUILD_ID", {
  name:        "ping",
  description: "Replies with Pong!",
  options: []
})
```

#### `bot.deleteCommand(guildId, commandId)`
Delete a slash command.

---

### Interactions

#### `bot.respondToInteraction(interactionId, interactionToken, content, options?)`
Respond to an interaction (type 4 — channel message with source).

| Option       | Type    | Description              |
|--------------|---------|--------------------------|
| `embed`      | object  | Embed to include         |
| `ephemeral`  | boolean | Only visible to invoker  |
| `components` | array   | UI components            |

#### `bot.respondModal(interactionId, interactionToken, customId, title, components)`
Respond to an interaction with a modal (type 9).

#### `bot.deferInteraction(interactionId, interactionToken, ephemeral?)`
Defer an interaction response (type 5). Use when you need more than 3 seconds to respond.

#### `bot.editInteractionResponse(interactionToken, content, options?)`
Edit a previously deferred or sent interaction response.

---

### Webhooks

#### `bot.createWebhook(channelId, name, avatar?)`
Create a webhook in a channel.

#### `bot.executeWebhook(webhookId, webhookToken, content, options?)`
Send a message via a webhook.

| Option      | Type   | Description              |
|-------------|--------|--------------------------|
| `username`  | string | Override display name    |
| `avatarUrl` | string | Override avatar URL      |
| `embed`     | object | Embed to include         |
| `components`| array  | UI components            |

---

### Voice

#### `bot.joinVoice(guildId, channelId, mute?, deaf?)`
Join a voice channel. `mute` and `deaf` default to `false`.

#### `bot.leaveVoice(guildId)`
Leave the current voice channel in a guild.

#### `bot.muteVoice(guildId, mute?)`
Toggle self-mute. `mute` defaults to `true`.

#### `bot.getVoiceState(guildId, userId?)`
Get a voice state. If `userId` is omitted, returns the bot's own state.

#### `bot.modifyVoiceState(guildId, channelId, options?)`
Modify the bot's voice state.

| Option           | Type    | Description                          |
|------------------|---------|--------------------------------------|
| `suppress`       | boolean | Suppress the bot in a stage channel  |
| `requestToSpeak` | string  | ISO8601 timestamp to request to speak|

---

### Stage Instances

#### `bot.createStageInstance(channelId, topic, privacyLevel?)`
Create a stage instance. `privacyLevel` defaults to `1` (guild only).

#### `bot.getStageInstance(channelId)`
Fetch a stage instance.

#### `bot.editStageInstance(channelId, topic?, privacyLevel?)`
Edit a stage instance.

#### `bot.deleteStageInstance(channelId)`
Delete a stage instance.

#### `bot.requestToSpeak(guildId)`
Request to speak in a stage channel.

---

### UI Components

#### `bot.embed(options)`
Build an embed object.

```ntl
val e = bot.embed({
  title:       "Title",
  description: "Description",
  color:       0x5865F2,
  url:         "https://example.com",
  thumbnail:   "https://example.com/thumb.png",
  image:       "https://example.com/img.png",
  footer:      "Footer text",
  author:      "Author name",
  timestamp:   new Date().toISOString(),
  fields: [
    { name: "Field 1", value: "Value 1", inline: true },
    { name: "Field 2", value: "Value 2", inline: true }
  ]
})
```

#### `bot.button(options)`
Build a button component.

```ntl
bot.button({
  label:    "Click me",
  customId: "my_button",
  style:    discordntl.BUTTON_STYLES.primary,
  emoji:    { name: "👋" },
  disabled: false
})
```

For link buttons, use `url` instead of `customId` and `style: discordntl.BUTTON_STYLES.link`.

#### `bot.actionRow(components)`
Wrap components in an action row.

```ntl
bot.actionRow([ bot.button({ label: "OK", customId: "ok" }) ])
```

#### `bot.stringSelect(options)`
#### `bot.userSelect(options)`
#### `bot.roleSelect(options)`
#### `bot.channelSelect(options)`
#### `bot.mentionableSelect(options)`
Build select menu components.

```ntl
bot.stringSelect({
  customId:    "my_select",
  placeholder: "Choose an option",
  minValues:   1,
  maxValues:   1,
  options: [
    { label: "Option A", value: "a" },
    { label: "Option B", value: "b" }
  ]
})
```

#### `bot.textInput(options)`
Build a text input (for use inside modals).

```ntl
bot.textInput({
  customId:    "my_input",
  label:       "Enter text",
  style:       discordntl.TEXT_INPUT_STYLES.short,
  placeholder: "Type here...",
  required:    true,
  minLength:   1,
  maxLength:   100
})
```

#### `bot.modal(customId, title, rows)`
Build a modal object.

```ntl
bot.modal("my_modal", "My Form", [
  bot.actionRow([ bot.textInput({ customId: "name", label: "Name" }) ])
])
```

---

### Router

The router automatically registers slash commands on `READY` and dispatches `INTERACTION_CREATE` events.

#### `bot.router(guildId?)`
Create a slash command router. Pass `null` or omit `guildId` for global commands.

```ntl
val r = bot.router("GUILD_ID")

r.command("ping", "Replies with Pong!", fn(ctx) {
  ctx.reply("Pong!")
})

r.command("greet", "Greet someone", [
  { type: 3, name: "name", description: "The name to greet", required: true }
], fn(ctx) {
  val name = ctx.option("name")
  ctx.reply("Hello, " + name + "!")
})

r.component("my_button", fn(ctx, values) {
  ctx.reply("Button clicked!")
})

r.modal("my_modal", fn(ctx, fields) {
  ctx.reply("Form submitted!")
})
```

#### Context object (`ctx`)

| Property / Method              | Description                                       |
|-------------------------------|---------------------------------------------------|
| `ctx.interaction`             | Raw interaction object                            |
| `ctx.user`                    | The user who triggered the interaction            |
| `ctx.guildId`                 | Guild ID                                          |
| `ctx.channelId`               | Channel ID                                        |
| `ctx.option(name)`            | Get a slash command option value by name          |
| `ctx.options`                 | Raw options array                                 |
| `ctx.reply(content, opts?)`   | Respond to the interaction                        |
| `ctx.replyEphemeral(content)` | Respond ephemerally (only visible to the user)    |
| `ctx.defer(ephemeral?)`       | Defer the response                                |
| `ctx.edit(content, opts?)`    | Edit the deferred/original response               |
| `ctx.showModal(id, title, rows)` | Respond with a modal                          |

#### Middleware

```ntl
r.use(fn(interaction) {
  if interaction.guild_id === undefined {
    return false
  }
})
```

Return `false` from a middleware function to block the interaction from being dispatched.

---

### Constants

All constants are exported directly from the module:

```ntl
discordntl.INTENTS.guildMessages
discordntl.BUTTON_STYLES.danger
discordntl.CHANNEL_TYPES.guildText
discordntl.TEXT_INPUT_STYLES.paragraph
discordntl.COMPONENT_TYPES.button
discordntl.OPCODES.identify
```

---

## Complete Bot Example

```ntl
use "discordntl"
use env
use io

val bot = discordntl.create(env.get("DISCORD_TOKEN"), {
  intents: discordntl.INTENTS.guilds | discordntl.INTENTS.guildMessages | discordntl.INTENTS.messageContent
})

val r = bot.router(env.get("GUILD_ID"))

r.command("ping", "Check latency", fn(ctx) {
  ctx.reply("Pong!")
})

r.command("say", "Repeat a message", [
  { type: 3, name: "text", description: "Text to repeat", required: true }
], fn(ctx) {
  val text = ctx.option("text")
  ctx.reply(text)
})

bot.on("READY", fn(data) {
  io.log("Ready as " + data.user.username)
  bot.setPresence("online", { name: "NTL", type: 3 })
})

bot.on("ERROR", fn(err) {
  io.log("Error: " + err.message)
})

bot.connect()
```

---

## License

GPL-3.0
