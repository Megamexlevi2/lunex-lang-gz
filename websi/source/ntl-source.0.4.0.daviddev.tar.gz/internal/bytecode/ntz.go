// NTL lang — NTZ Bytecode Compiler
// Compiles NTL AST to Zig VM-compatible opcodes (NTZ format).
// The compiled opcodes are appended to the NC container so the
// Zig runtime can detect and execute them directly, making Zig
// the primary execution engine for supported programs.
//
// Supported features: literals, variables, arithmetic, comparisons,
// logical ops, if/else, while, for, arrays, objects, built-in calls,
// member access, index access, break/continue, return.
//
// Unsupported features (fall back to Go interpreter): closures,
// classes, imports, async/await, generators, complex destructuring.

package bytecode

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"math"
	"ntl/internal/ast"
)

// ErrNTZUnsupported is returned when the source contains features the
// NTZ compiler cannot handle. The caller should omit the NTZ section
// and let Go's interpreter handle the program.
var ErrNTZUnsupported = fmt.Errorf("ntl: feature not supported by NTZ compiler")

// NTZ opcode values — must exactly match the Opcode enum in zig/src/vm.zig.
const (
	ntzConst       = 0
	ntzLoad        = 1
	ntzStore       = 2
	ntzAdd         = 3
	ntzSub         = 4
	ntzMul         = 5
	ntzDiv         = 6
	ntzMod         = 7
	ntzNeg         = 8
	ntzNot         = 9
	ntzBitAnd      = 10
	ntzBitOr       = 11
	ntzBitXor      = 12
	ntzBitNot      = 13
	ntzShl         = 14
	ntzShr         = 15
	ntzEq          = 16
	ntzNeq         = 17
	ntzLt          = 18
	ntzLte         = 19
	ntzGt          = 20
	ntzGte         = 21
	ntzAnd         = 22
	ntzOr          = 23
	ntzCall        = 24
	ntzCallRT      = 25
	ntzReturn      = 26
	ntzJump        = 27
	ntzJumpIf      = 28
	ntzJumpIfFalse = 29
	ntzGetField    = 30
	ntzSetField    = 31
	ntzGetIndex    = 32
	ntzSetIndex    = 33
	ntzMakeArray   = 34
	ntzMakeObject  = 35
	ntzSpread      = 36
	ntzIter        = 37
	ntzIterNext    = 38
	ntzThrow       = 39
	ntzTry         = 40
	ntzCatch       = 41
	ntzHalt        = 42
	ntzPop         = 43 // Pop top of stack — extension added to Zig VM
)

// Const-kind tags (sub-byte after Const opcode).
const (
	ntzConstNull   = 0
	ntzConstBool   = 1
	ntzConstInt    = 2
	ntzConstFloat  = 3
	ntzConstString = 4
)

// patchSite records the byte offset of a 4-byte jump target that
// must be backpatched once the real destination address is known.
type patchSite struct{ offset int }

// loopCtx tracks information needed to resolve break/continue inside loops.
type loopCtx struct {
	continueTarget int   // bytecode offset to jump to on continue
	breakSites     []int // byte offsets of break-jump targets to patch
}

// ntzC is the NTZ bytecode compiler state.
type ntzC struct {
	buf      bytes.Buffer
	vars     map[string]uint16 // variable name → stack slot index
	nextSlot uint16
	loops    []loopCtx
}

// CompileNTZ walks a parsed NTL AST and emits Zig VM-compatible bytecode.
// Returns ErrNTZUnsupported if any feature cannot be compiled.
func CompileNTZ(tree *ast.Node) ([]byte, error) {
	if tree == nil {
		return []byte{ntzHalt}, nil
	}
	c := &ntzC{vars: make(map[string]uint16)}
	if err := c.stmt(tree); err != nil {
		return nil, err
	}
	c.emit(ntzHalt)
	return c.buf.Bytes(), nil
}

// ─── emit helpers ─────────────────────────────────────────────────────────────

func (c *ntzC) emit(b ...byte) { c.buf.Write(b) }

func (c *ntzC) emitU8(v uint8) { c.buf.WriteByte(v) }

func (c *ntzC) emitU16(v uint16) {
	var b [2]byte
	binary.LittleEndian.PutUint16(b[:], v)
	c.buf.Write(b[:])
}

func (c *ntzC) emitU32(v uint32) {
	var b [4]byte
	binary.LittleEndian.PutUint32(b[:], v)
	c.buf.Write(b[:])
}

func (c *ntzC) emitI64(v int64) {
	var b [8]byte
	binary.LittleEndian.PutUint64(b[:], uint64(v))
	c.buf.Write(b[:])
}

func (c *ntzC) emitF64(v float64) {
	var b [8]byte
	binary.LittleEndian.PutUint64(b[:], math.Float64bits(v))
	c.buf.Write(b[:])
}

func (c *ntzC) pos() int { return c.buf.Len() }

func (c *ntzC) emitJump(op byte) patchSite {
	c.emitU8(op)
	pt := patchSite{offset: c.buf.Len()}
	c.emitU32(0) // placeholder — patched later
	return pt
}

func (c *ntzC) patch(pt patchSite, target int) {
	binary.LittleEndian.PutUint32(c.buf.Bytes()[pt.offset:], uint32(target))
}

func (c *ntzC) patchAt(offset int, target int) {
	binary.LittleEndian.PutUint32(c.buf.Bytes()[offset:], uint32(target))
}

func (c *ntzC) varSlot(name string) uint16 {
	if slot, ok := c.vars[name]; ok {
		return slot
	}
	slot := c.nextSlot
	c.vars[name] = slot
	c.nextSlot++
	return slot
}

func (c *ntzC) emitName(name string) {
	c.emitU8(uint8(len(name)))
	c.buf.WriteString(name)
}

// ─── statement compilation ────────────────────────────────────────────────────

func (c *ntzC) stmt(n *ast.Node) error {
	if n == nil {
		return nil
	}
	switch n.Type {
	case ast.Program:
		for _, s := range n.Body_ {
			if err := c.stmt(s); err != nil {
				return err
			}
		}

	case ast.Block:
		for _, s := range n.Body_ {
			if err := c.stmt(s); err != nil {
				return err
			}
		}

	case ast.VarDecl, ast.ImmutableDecl, ast.UsingDecl:
		if n.Init != nil {
			if err := c.expr(n.Init); err != nil {
				return err
			}
		} else {
			c.emitU8(ntzConst)
			c.emitU8(ntzConstNull)
		}
		slot := c.varSlot(n.Name)
		c.emitU8(ntzStore)
		c.emitU16(slot)
		c.emitU8(ntzPop) // discard leftover value from Store (peek semantics)

	case ast.ExprStmt:
		if n.Expr != nil {
			if err := c.expr(n.Expr); err != nil {
				return err
			}
			c.emitU8(ntzPop)
		}

	case ast.LogStmt:
		for _, arg := range n.Args {
			if err := c.expr(arg); err != nil {
				return err
			}
		}
		c.emitU8(ntzCallRT)
		c.emitName("log")
		c.emitU8(uint8(len(n.Args)))
		c.emitU8(ntzPop)

	case ast.ReturnStmt:
		if n.Expr != nil {
			if err := c.expr(n.Expr); err != nil {
				return err
			}
		} else {
			c.emitU8(ntzConst)
			c.emitU8(ntzConstNull)
		}
		c.emitU8(ntzReturn)

	case ast.ThrowStmt, ast.RaiseStmt:
		if n.Expr != nil {
			if err := c.expr(n.Expr); err != nil {
				return err
			}
		} else {
			c.emitU8(ntzConst)
			c.emitU8(ntzConstNull)
		}
		c.emitU8(ntzThrow)

	case ast.IfStmt, ast.UnlessStmt:
		if err := c.compileIf(n); err != nil {
			return err
		}

	case ast.WhileStmt:
		if err := c.compileWhile(n); err != nil {
			return err
		}

	case ast.ForStmt:
		if err := c.compileFor(n); err != nil {
			return err
		}

	case ast.BreakStmt:
		if len(c.loops) == 0 {
			return fmt.Errorf("ntl/ntz: break outside loop")
		}
		jmp := c.emitJump(ntzJump)
		c.loops[len(c.loops)-1].breakSites = append(
			c.loops[len(c.loops)-1].breakSites, jmp.offset)

	case ast.ContinueStmt:
		if len(c.loops) == 0 {
			return fmt.Errorf("ntl/ntz: continue outside loop")
		}
		target := c.loops[len(c.loops)-1].continueTarget
		c.emitU8(ntzJump)
		c.emitU32(uint32(target))

	case ast.AssertStmt:
		// assert expr → if !expr throw "assertion failed"
		if n.Expr != nil {
			if err := c.expr(n.Expr); err != nil {
				return err
			}
		} else {
			c.emitU8(ntzConst)
			c.emitU8(ntzConstBool)
			c.emitU8(1)
		}
		jmp := c.emitJump(ntzJumpIf) // skip throw if true
		c.emitU8(ntzConst)
		c.emitU8(ntzConstString)
		msg := "assertion failed"
		c.emitU32(uint32(len(msg)))
		c.buf.WriteString(msg)
		c.emitU8(ntzThrow)
		c.patch(jmp, c.pos())

	// Unsupported statements → fall back to Go interpreter
	case ast.FnDecl, ast.ClassDecl, ast.EnumDecl, ast.NamespaceDecl,
		ast.ComponentDecl, ast.ImportDecl, ast.ExportDecl, ast.NTLRequire,
		ast.UseStmt, ast.TryStmt, ast.SpawnStmt, ast.SelectStmt,
		ast.WithStmt, ast.HaveStmt, ast.IfHaveStmt, ast.IfSetStmt,
		ast.MatchStmt, ast.GuardStmt, ast.DeferStmt, ast.DeleteStmt,
		ast.RepeatStmt, ast.LoopStmt, ast.ForOfStmt, ast.EachInStmt:
		return ErrNTZUnsupported

	default:
		// Unknown statement — attempt as expression (e.g. FnExpr at top level)
		if err := c.expr(n); err != nil {
			return err
		}
		c.emitU8(ntzPop)
	}
	return nil
}

func (c *ntzC) compileIf(n *ast.Node) error {
	cond := n.Test
	if cond == nil {
		return ErrNTZUnsupported
	}
	if err := c.expr(cond); err != nil {
		return err
	}
	// UnlessStmt → negate condition
	if n.Type == ast.UnlessStmt {
		c.emitU8(ntzNot)
	}
	jmpFalse := c.emitJump(ntzJumpIfFalse)
	if err := c.stmt(n.Consequent); err != nil {
		return err
	}
	if n.Alternate != nil {
		jmpEnd := c.emitJump(ntzJump)
		c.patch(jmpFalse, c.pos())
		if err := c.stmt(n.Alternate); err != nil {
			return err
		}
		c.patch(jmpEnd, c.pos())
	} else {
		c.patch(jmpFalse, c.pos())
	}
	return nil
}

func (c *ntzC) compileWhile(n *ast.Node) error {
	loopStart := c.pos()
	if err := c.expr(n.Test); err != nil {
		return err
	}
	jmpEnd := c.emitJump(ntzJumpIfFalse)
	c.loops = append(c.loops, loopCtx{continueTarget: loopStart})
	if err := c.stmt(n.Body); err != nil {
		return err
	}
	c.emitU8(ntzJump)
	c.emitU32(uint32(loopStart))
	c.patch(jmpEnd, c.pos())
	c.patchBreaks()
	return nil
}

func (c *ntzC) compileFor(n *ast.Node) error {
	// for (Init; Test; Update) Body
	// Init is a statement node (VarDecl or ExprStmt)
	if n.Init != nil {
		if err := c.stmt(n.Init); err != nil {
			return err
		}
	}
	loopStart := c.pos()
	var jmpEnd patchSite
	hasTest := n.Test != nil
	if hasTest {
		if err := c.expr(n.Test); err != nil {
			return err
		}
		jmpEnd = c.emitJump(ntzJumpIfFalse)
	}
	c.loops = append(c.loops, loopCtx{continueTarget: loopStart})
	if err := c.stmt(n.Body); err != nil {
		return err
	}
	// Update expression (stored in node.Right for ForStmt)
	if n.Right != nil {
		if err := c.expr(n.Right); err != nil {
			return err
		}
		c.emitU8(ntzPop)
	}
	c.emitU8(ntzJump)
	c.emitU32(uint32(loopStart))
	if hasTest {
		c.patch(jmpEnd, c.pos())
	}
	c.patchBreaks()
	return nil
}

func (c *ntzC) patchBreaks() {
	if len(c.loops) == 0 {
		return
	}
	end := c.pos()
	for _, site := range c.loops[len(c.loops)-1].breakSites {
		c.patchAt(site, end)
	}
	c.loops = c.loops[:len(c.loops)-1]
}

// ─── expression compilation ───────────────────────────────────────────────────

func (c *ntzC) expr(n *ast.Node) error {
	if n == nil {
		c.emitU8(ntzConst)
		c.emitU8(ntzConstNull)
		return nil
	}
	switch n.Type {
	case ast.NumberLit:
		return c.emitNumber(n.Value)

	case ast.StringLit:
		s := ""
		if n.Value != nil {
			s = fmt.Sprintf("%v", n.Value)
		}
		c.emitU8(ntzConst)
		c.emitU8(ntzConstString)
		c.emitU32(uint32(len(s)))
		c.buf.WriteString(s)

	case ast.BoolLit:
		c.emitU8(ntzConst)
		c.emitU8(ntzConstBool)
		if n.Value == true {
			c.emitU8(1)
		} else {
			c.emitU8(0)
		}

	case ast.NullLit, ast.UndefinedLit:
		c.emitU8(ntzConst)
		c.emitU8(ntzConstNull)

	case ast.Identifier:
		name := n.Name
		if slot, ok := c.vars[name]; ok {
			c.emitU8(ntzLoad)
			c.emitU16(slot)
		} else {
			// Identifier not declared as local — treat as uninitialized (null)
			// This handles cases where variables may have been declared elsewhere
			slot = c.varSlot(name)
			c.emitU8(ntzLoad)
			c.emitU16(slot)
		}

	case ast.BinaryExpr:
		return c.compileBinary(n)

	case ast.UnaryExpr, ast.NotExpr:
		return c.compileUnary(n)

	case ast.LogicalExpr:
		return c.compileLogical(n)

	case ast.AssignExpr:
		return c.compileAssign(n)

	case ast.CallExpr:
		return c.compileCall(n)

	case ast.MemberExpr:
		return c.compileMember(n)

	case ast.ArrayLit:
		for _, el := range n.Elements {
			if err := c.expr(el); err != nil {
				return err
			}
		}
		c.emitU8(ntzMakeArray)
		c.emitU16(uint16(len(n.Elements)))

	case ast.ObjectLit:
		return c.compileObject(n)

	case ast.TernaryExpr:
		return c.compileTernary(n)

	case ast.SpreadExpr:
		if err := c.expr(n.Expr); err != nil {
			return err
		}
		c.emitU8(ntzSpread)

	case ast.VoidExpr:
		if n.Expr != nil {
			if err := c.expr(n.Expr); err != nil {
				return err
			}
			c.emitU8(ntzPop)
		}
		c.emitU8(ntzConst)
		c.emitU8(ntzConstNull)

	case ast.TypeofExpr:
		// typeof expr → CallRT "typeof" 1
		if err := c.expr(n.Expr); err != nil {
			return err
		}
		c.emitU8(ntzCallRT)
		c.emitName("typeof")
		c.emitU8(1)

	// Unsupported expressions → fall back to Go interpreter
	case ast.FnExpr, ast.ArrowFn, ast.NewExpr, ast.TemplateLit,
		ast.PipelineExpr, ast.SequenceExpr, ast.HaveExpr,
		ast.TrySafeExpr, ast.RangeExpr, ast.SleepExpr,
		ast.ChannelExpr, ast.NaxImportExpr, ast.ThisExpr,
		ast.SuperExpr, ast.SatisfiesExpr, ast.DecoratedExpr,
		ast.RegexLit, ast.DeleteExpr:
		return ErrNTZUnsupported

	default:
		return ErrNTZUnsupported
	}
	return nil
}

func (c *ntzC) emitNumber(v interface{}) error {
	switch val := v.(type) {
	case int64:
		c.emitU8(ntzConst)
		c.emitU8(ntzConstInt)
		c.emitI64(val)
	case int:
		c.emitU8(ntzConst)
		c.emitU8(ntzConstInt)
		c.emitI64(int64(val))
	case float64:
		// Emit as integer if it's a whole number in range
		if val == math.Trunc(val) && val >= -9e15 && val <= 9e15 {
			c.emitU8(ntzConst)
			c.emitU8(ntzConstInt)
			c.emitI64(int64(val))
		} else {
			c.emitU8(ntzConst)
			c.emitU8(ntzConstFloat)
			c.emitF64(val)
		}
	default:
		c.emitU8(ntzConst)
		c.emitU8(ntzConstFloat)
		c.emitF64(0)
	}
	return nil
}

func (c *ntzC) compileBinary(n *ast.Node) error {
	if err := c.expr(n.Left); err != nil {
		return err
	}
	if err := c.expr(n.Right); err != nil {
		return err
	}
	switch n.Op {
	case "+":
		c.emitU8(ntzAdd)
	case "-":
		c.emitU8(ntzSub)
	case "*":
		c.emitU8(ntzMul)
	case "/":
		c.emitU8(ntzDiv)
	case "%":
		c.emitU8(ntzMod)
	case "==", "===":
		c.emitU8(ntzEq)
	case "!=", "!==":
		c.emitU8(ntzNeq)
	case "<":
		c.emitU8(ntzLt)
	case "<=":
		c.emitU8(ntzLte)
	case ">":
		c.emitU8(ntzGt)
	case ">=":
		c.emitU8(ntzGte)
	case "&":
		c.emitU8(ntzBitAnd)
	case "|":
		c.emitU8(ntzBitOr)
	case "^":
		c.emitU8(ntzBitXor)
	case "<<":
		c.emitU8(ntzShl)
	case ">>":
		c.emitU8(ntzShr)
	default:
		return fmt.Errorf("ntl/ntz: unsupported binary op %q", n.Op)
	}
	return nil
}

func (c *ntzC) compileUnary(n *ast.Node) error {
	arg := n.Arg
	if arg == nil {
		arg = n.Expr
	}
	if err := c.expr(arg); err != nil {
		return err
	}
	switch n.Op {
	case "-":
		c.emitU8(ntzNeg)
	case "!", "not":
		c.emitU8(ntzNot)
	case "~":
		c.emitU8(ntzBitNot)
	case "+":
		// unary + is a no-op for numbers
	default:
		return fmt.Errorf("ntl/ntz: unsupported unary op %q", n.Op)
	}
	return nil
}

func (c *ntzC) compileLogical(n *ast.Node) error {
	switch n.Op {
	case "&&":
		// Short-circuit AND: if left is falsy, return left; else evaluate right
		if err := c.expr(n.Left); err != nil {
			return err
		}
		// Duplicate top for the short-circuit check
		// Save to temp slot, load it, jump if false
		temp := c.nextSlot
		c.nextSlot++
		c.emitU8(ntzStore)
		c.emitU16(temp)
		c.emitU8(ntzLoad)
		c.emitU16(temp)
		jmpFalse := c.emitJump(ntzJumpIfFalse)
		c.emitU8(ntzPop) // discard the duplicated left
		if err := c.expr(n.Right); err != nil {
			return err
		}
		jmpEnd := c.emitJump(ntzJump)
		c.patch(jmpFalse, c.pos())
		// left value is already on stack (we loaded it from temp)
		c.patch(jmpEnd, c.pos())

	case "||":
		// Short-circuit OR: if left is truthy, return left; else evaluate right
		if err := c.expr(n.Left); err != nil {
			return err
		}
		temp := c.nextSlot
		c.nextSlot++
		c.emitU8(ntzStore)
		c.emitU16(temp)
		c.emitU8(ntzLoad)
		c.emitU16(temp)
		jmpTrue := c.emitJump(ntzJumpIf)
		c.emitU8(ntzPop) // discard duplicated left
		if err := c.expr(n.Right); err != nil {
			return err
		}
		jmpEnd := c.emitJump(ntzJump)
		c.patch(jmpTrue, c.pos())
		c.patch(jmpEnd, c.pos())

	default:
		return fmt.Errorf("ntl/ntz: unsupported logical op %q", n.Op)
	}
	return nil
}

func (c *ntzC) compileAssign(n *ast.Node) error {
	target := n.Left
	op := n.Op

	switch target.Type {
	case ast.Identifier:
		slot := c.varSlot(target.Name)
		if op == "=" {
			if err := c.expr(n.Right); err != nil {
				return err
			}
		} else {
			// Compound: load, compile RHS, apply op
			c.emitU8(ntzLoad)
			c.emitU16(slot)
			if err := c.expr(n.Right); err != nil {
				return err
			}
			if err := c.emitCompoundOp(op); err != nil {
				return err
			}
		}
		c.emitU8(ntzStore)
		c.emitU16(slot)
		// Store is peek — value remains on stack as the expression result

	case ast.MemberExpr:
		if target.Computed {
			// arr[idx] = val
			if op != "=" {
				return ErrNTZUnsupported
			}
			if err := c.expr(target.Object); err != nil {
				return err
			}
			if err := c.compileIndex(target.Prop); err != nil {
				return err
			}
			if err := c.expr(n.Right); err != nil {
				return err
			}
			c.emitU8(ntzSetIndex)
			// Stack: obj still on top (SetIndex peeks obj)
		} else {
			// obj.field = val
			if op != "=" {
				return ErrNTZUnsupported
			}
			if err := c.expr(target.Object); err != nil {
				return err
			}
			if err := c.expr(n.Right); err != nil {
				return err
			}
			name := c.fieldName(target)
			c.emitU8(ntzSetField)
			c.emitU8(uint8(len(name)))
			c.buf.WriteString(name)
			// Stack: obj still on top (SetField peeks obj)
		}
		// Push the assigned value as the expression result
		// (we don't have easy access to it after SetField/SetIndex)
		c.emitU8(ntzConst)
		c.emitU8(ntzConstNull)

	default:
		return ErrNTZUnsupported
	}
	return nil
}

func (c *ntzC) emitCompoundOp(op string) error {
	switch op {
	case "+=":
		c.emitU8(ntzAdd)
	case "-=":
		c.emitU8(ntzSub)
	case "*=":
		c.emitU8(ntzMul)
	case "/=":
		c.emitU8(ntzDiv)
	case "%=":
		c.emitU8(ntzMod)
	case "&=":
		c.emitU8(ntzBitAnd)
	case "|=":
		c.emitU8(ntzBitOr)
	case "^=":
		c.emitU8(ntzBitXor)
	case "<<=":
		c.emitU8(ntzShl)
	case ">>=":
		c.emitU8(ntzShr)
	default:
		return fmt.Errorf("ntl/ntz: unsupported compound assignment %q", op)
	}
	return nil
}

func (c *ntzC) compileCall(n *ast.Node) error {
	if n.Callee == nil {
		return ErrNTZUnsupported
	}

	// Direct built-in call: name(args)
	if n.Callee.Type == ast.Identifier {
		for _, arg := range n.Args {
			if err := c.expr(arg); err != nil {
				return err
			}
		}
		name := n.Callee.Name
		c.emitU8(ntzCallRT)
		c.emitU8(uint8(len(name)))
		c.buf.WriteString(name)
		c.emitU8(uint8(len(n.Args)))
		return nil
	}

	// Method call: obj.method(args) → push args, CallRT "method" N
	// We redirect method calls to the global built-in of the same name.
	if n.Callee.Type == ast.MemberExpr {
		callee := n.Callee
		method := c.fieldName(callee)
		if method == "" {
			return ErrNTZUnsupported
		}
		// Push the object as the first implicit argument
		if err := c.expr(callee.Object); err != nil {
			return err
		}
		for _, arg := range n.Args {
			if err := c.expr(arg); err != nil {
				return err
			}
		}
		c.emitU8(ntzCallRT)
		c.emitU8(uint8(len(method)))
		c.buf.WriteString(method)
		c.emitU8(uint8(1 + len(n.Args))) // object + args
		return nil
	}

	return ErrNTZUnsupported
}

func (c *ntzC) compileMember(n *ast.Node) error {
	if err := c.expr(n.Object); err != nil {
		return err
	}
	if n.Computed {
		if err := c.compileIndex(n.Prop); err != nil {
			return err
		}
		c.emitU8(ntzGetIndex)
		return nil
	}
	name := c.fieldName(n)
	c.emitU8(ntzGetField)
	c.emitU8(uint8(len(name)))
	c.buf.WriteString(name)
	return nil
}

func (c *ntzC) compileIndex(prop interface{}) error {
	switch p := prop.(type) {
	case *ast.Node:
		return c.expr(p)
	default:
		c.emitU8(ntzConst)
		c.emitU8(ntzConstNull)
		return nil
	}
}

func (c *ntzC) compileObject(n *ast.Node) error {
	for _, prop := range n.Properties {
		// Key
		key := ""
		switch k := prop.Key.(type) {
		case string:
			key = k
		case *ast.Node:
			if k != nil {
				switch k.Type {
				case ast.Identifier:
					key = k.Name
				case ast.StringLit:
					if s, ok := k.Value.(string); ok {
						key = s
					}
				}
			}
		}
		c.emitU8(ntzConst)
		c.emitU8(ntzConstString)
		c.emitU32(uint32(len(key)))
		c.buf.WriteString(key)
		// Value — skip methods/getters/setters for now
		if prop.Value != nil {
			if prop.Value.Type == ast.FnExpr || prop.Value.Type == ast.ArrowFn {
				return ErrNTZUnsupported
			}
			if err := c.expr(prop.Value); err != nil {
				return err
			}
		} else {
			c.emitU8(ntzConst)
			c.emitU8(ntzConstNull)
		}
	}
	c.emitU8(ntzMakeObject)
	c.emitU16(uint16(len(n.Properties)))
	return nil
}

func (c *ntzC) compileTernary(n *ast.Node) error {
	if err := c.expr(n.Test); err != nil {
		return err
	}
	jmpFalse := c.emitJump(ntzJumpIfFalse)
	if err := c.expr(n.Consequent); err != nil {
		return err
	}
	jmpEnd := c.emitJump(ntzJump)
	c.patch(jmpFalse, c.pos())
	if err := c.expr(n.Alternate); err != nil {
		return err
	}
	c.patch(jmpEnd, c.pos())
	return nil
}

// fieldName extracts the field name string from a MemberExpr node.
func (c *ntzC) fieldName(n *ast.Node) string {
	if n.Prop == nil {
		return ""
	}
	switch p := n.Prop.(type) {
	case string:
		return p
	case *ast.Node:
		if p == nil {
			return ""
		}
		if p.Type == ast.Identifier {
			return p.Name
		}
		if p.Type == ast.StringLit {
			if s, ok := p.Value.(string); ok {
				return s
			}
		}
	}
	return ""
}
