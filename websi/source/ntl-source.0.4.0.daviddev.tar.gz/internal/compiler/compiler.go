// NTL lang
// Created by David Dev · GitHub: https://github.com/Megamexlevi2
// (c) David Dev 2026. License.

package compiler

import (
        "fmt"
        "ntl/internal/ast"
        "ntl/internal/errfmt"
        "ntl/internal/lexer"
        "ntl/internal/parser"
        "ntl/internal/runtime"
        "os"
        "path/filepath"
        "strings"
        "time"
)

const NTLVersion = "0.3.0"

type Options struct {
        Strict    bool
        TypeCheck bool
        Silent    bool
        Profile   bool
        REPL      bool
}

var DefaultOptions = Options{
        Silent:  true,
        Profile: false,
}

type CompileResult struct {
        AST      *ast.Node
        Errors   []*errfmt.NTLError
        Warnings []*errfmt.NTLError
        Time     time.Duration
        Success  bool
}

type Compiler struct {
        opts        Options
        interp      *runtime.Interpreter
        moduleCache map[string]*runtime.Value
}

func New(opts Options) *Compiler {
        c := &Compiler{
                opts:        opts,
                interp:      runtime.NewInterpreter(),
                moduleCache: make(map[string]*runtime.Value),
        }
        c.registerStdlib()
        return c
}

func (c *Compiler) Interpreter() *runtime.Interpreter {
        return c.interp
}

func (c *Compiler) CompileSource(source, filename string) *CompileResult {
        start := time.Now()
        lines := strings.Split(source, "\n")
        result := &CompileResult{}

        tokens, err := lexer.Tokenize(source, filename)
        if err != nil {
                hint := errfmt.SuggestForMessage(err.Error())
                result.Errors = append(result.Errors, &errfmt.NTLError{
                        Message:    err.Error(),
                        File:       filename,
                        Kind:       errfmt.KindLex,
                        Suggestion: hint,
                        Lines:      lines,
                })
                result.Time = time.Since(start)
                return result
        }

        tree, err := parser.Parse(tokens, filename)
        if err != nil {
                if pe, ok := err.(*parser.ParseError); ok {
                        hint := errfmt.SuggestForMessage(pe.Message)
                        result.Errors = append(result.Errors, &errfmt.NTLError{
                                Message:    pe.Message,
                                File:       filename,
                                Line:       pe.Line,
                                Col:        pe.Col,
                                Kind:       errfmt.KindParse,
                                Suggestion: hint,
                                Lines:      lines,
                        })
                } else {
                        hint := errfmt.SuggestForMessage(err.Error())
                        result.Errors = append(result.Errors, &errfmt.NTLError{
                                Message:    err.Error(),
                                File:       filename,
                                Kind:       errfmt.KindParse,
                                Suggestion: hint,
                                Lines:      lines,
                        })
                }
                result.Time = time.Since(start)
                return result
        }

        result.AST = tree
        result.Success = true
        result.Time = time.Since(start)
        return result
}

func (c *Compiler) RunFile(filePath string) error {
        source, err := os.ReadFile(filePath)
        if err != nil {
                fmt.Fprint(os.Stderr, errfmt.Format(&errfmt.NTLError{
                        Message:    fmt.Sprintf("cannot read file '%s': %v", filePath, err),
                        File:       filePath,
                        Kind:       errfmt.KindIO,
                        Suggestion: "check that the file exists and you have read permissions",
                }))
                return err
        }
        return c.RunSource(string(source), filePath)
}

func (c *Compiler) RunSource(source, filename string) error {
        result := c.CompileSource(source, filename)
        if !result.Success {
                for _, e := range result.Errors {
                        fmt.Fprint(os.Stderr, errfmt.Format(e))
                }
                return fmt.Errorf("compilation failed with %d error(s)", len(result.Errors))
        }
        return c.RunAST(result.AST, filename, source)
}

func (c *Compiler) RunAST(tree *ast.Node, filename, source string) error {
        c.interp.SetFilename(filename)
        c.interp.SetSourceLines(strings.Split(source, "\n"))
        _ = filepath.Dir(filename)

        _, execErr := c.interp.Exec(tree)
        if execErr != nil {
                c.printRuntimeError(execErr, filename, source)
                return execErr
        }
        if mainErr := c.interp.CallMain(); mainErr != nil {
                c.printRuntimeError(mainErr, filename, source)
                return mainErr
        }
        return nil
}

func (c *Compiler) printRuntimeError(err error, filename, source string) {
        srcLines := strings.Split(source, "\n")
        if ntlErr, ok := err.(*errfmt.NTLError); ok {
                if len(ntlErr.Lines) == 0 {
                        ntlErr.Lines = srcLines
                }
                if ntlErr.File == "" {
                        ntlErr.File = filename
                }
                fmt.Fprint(os.Stderr, errfmt.Format(ntlErr))
                return
        }

        msg := err.Error()
        hint := errfmt.SuggestForMessage(msg)

        kind := errfmt.KindRuntime
        if strings.HasPrefix(msg, "TypeError:") {
                kind = errfmt.KindType
                msg = strings.TrimPrefix(msg, "TypeError: ")
        } else if strings.HasPrefix(msg, "ReferenceError:") {
                kind = errfmt.KindReference
                msg = strings.TrimPrefix(msg, "ReferenceError: ")
        } else if strings.HasPrefix(msg, "ImportError:") {
                kind = errfmt.KindImport
                msg = strings.TrimPrefix(msg, "ImportError: ")
        }

        fmt.Fprint(os.Stderr, errfmt.Format(&errfmt.NTLError{
                Message:    msg,
                File:       filename,
                Kind:       kind,
                Lines:      srcLines,
                Suggestion: hint,
        }))
}

func (c *Compiler) Version() string {
        return NTLVersion
}

func (c *Compiler) Check(source, filename string) error {
        result := c.CompileSource(source, filename)
        if !result.Success {
                var msgs []string
                for _, e := range result.Errors {
                        msgs = append(msgs, e.Message)
                }
                return fmt.Errorf("%s", strings.Join(msgs, "; "))
        }
        return nil
}

func Format(source string) string {
        lines := strings.Split(source, "\n")
        var out []string
        indent := 0
        for _, raw := range lines {
                line := strings.TrimSpace(raw)
                if line == "" {
                        out = append(out, "")
                        continue
                }
                opens := strings.Count(line, "{") - strings.Count(line, "}")
                closes := strings.Count(line, "}")
                if closes > 0 && strings.HasPrefix(line, "}") {
                        indent -= closes
                        if indent < 0 {
                                indent = 0
                        }
                }
                out = append(out, strings.Repeat("  ", indent)+line)
                if opens > 0 {
                        indent += opens
                }
        }
        return strings.Join(out, "\n")
}

func (c *Compiler) registerStdlib() {}
