// NTL lang
// Created by David Dev · GitHub: https://github.com/Megamexlevi2
// (c) David Dev 2026. License.

package builtin

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/md5"
	"crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"hash"
	"ntl/internal/runtime"
	"strings"
	"time"
)

func hashString(algorithm, data string) string {
	var h hash.Hash
	switch strings.ToLower(algorithm) {
	case "md5":
		h = md5.New()
	case "sha1":
		h = sha1.New()
	case "sha256":
		h = sha256.New()
	case "sha512":
		h = sha512.New()
	default:
		h = sha256.New()
	}
	h.Write([]byte(data))
	return hex.EncodeToString(h.Sum(nil))
}

func hmacString(algorithm, key, data string) string {
	var h func() hash.Hash
	switch strings.ToLower(algorithm) {
	case "sha256":
		h = sha256.New
	case "sha512":
		h = sha512.New
	case "md5":
		h = md5.New
	case "sha1":
		h = sha1.New
	default:
		h = sha256.New
	}
	mac := hmac.New(h, []byte(key))
	mac.Write([]byte(data))
	return hex.EncodeToString(mac.Sum(nil))
}

func jwtSign(payload map[string]*runtime.Value, secret string, expiresIn int64) string {
	header := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))
	now := time.Now().Unix()
	claims := make(map[string]*runtime.Value)
	for k, v := range payload {
		claims[k] = v
	}
	if _, ok := claims["iat"]; !ok {
		claims["iat"] = runtime.NumberVal(float64(now))
	}
	if expiresIn > 0 {
		if _, ok := claims["exp"]; !ok {
			claims["exp"] = runtime.NumberVal(float64(now + expiresIn))
		}
	}
	payloadStr := valueToJSON(runtime.ObjectVal(claims))
	payloadB64 := base64.RawURLEncoding.EncodeToString([]byte(payloadStr))
	sigInput := header + "." + payloadB64
	sig := hmacString("sha256", secret, sigInput)
	sigB64 := base64.RawURLEncoding.EncodeToString([]byte(sig))
	return sigInput + "." + sigB64
}

func jwtVerify(token, secret string) (*runtime.Value, error) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return nil, fmt.Errorf("invalid JWT format")
	}
	sigInput := parts[0] + "." + parts[1]
	expectedSig := hmacString("sha256", secret, sigInput)
	expectedB64 := base64.RawURLEncoding.EncodeToString([]byte(expectedSig))
	if parts[2] != expectedB64 {
		return nil, fmt.Errorf("invalid signature")
	}
	payloadBytes, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return nil, fmt.Errorf("invalid payload encoding")
	}
	payload, err := parseJSON(string(payloadBytes))
	if err != nil {
		return nil, fmt.Errorf("invalid payload JSON")
	}
	if exp, ok := payload.ObjVal["exp"]; ok && exp != nil {
		if time.Now().Unix() > int64(exp.ToNumber()) {
			return nil, fmt.Errorf("token expired")
		}
	}
	return payload, nil
}

func aesEncrypt(plaintext, key string) (string, error) {
	k := []byte(key)
	for len(k) < 32 {
		k = append(k, 0)
	}
	k = k[:32]
	block, err := aes.NewCipher(k)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return "", err
	}
	ciphertext := gcm.Seal(nonce, nonce, []byte(plaintext), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func aesDecrypt(ciphertextB64, key string) (string, error) {
	k := []byte(key)
	for len(k) < 32 {
		k = append(k, 0)
	}
	k = k[:32]
	ciphertext, err := base64.StdEncoding.DecodeString(ciphertextB64)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(k)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	if len(ciphertext) < gcm.NonceSize() {
		return "", fmt.Errorf("ciphertext too short")
	}
	nonce, ciphertext := ciphertext[:gcm.NonceSize()], ciphertext[gcm.NonceSize():]
	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}
	return string(plaintext), nil
}

func simplePBKDF2(password, salt string, iterations int) string {
	key := hmacString("sha256", password, salt)
	for i := 1; i < iterations; i++ {
		key = hmacString("sha256", password, key)
	}
	return key
}

func CryptoModule() *runtime.Value {
	return runtime.ObjectVal(map[string]*runtime.Value{
		"hash": runtime.FuncVal(&runtime.Function{Name: "hash", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) < 2 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(hashString(args[0].ToString(), args[1].ToString())), nil
		}}),

		"hmac": runtime.FuncVal(&runtime.Function{Name: "hmac", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) < 3 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(hmacString(args[0].ToString(), args[1].ToString(), args[2].ToString())), nil
		}}),

		"md5": runtime.FuncVal(&runtime.Function{Name: "md5", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(hashString("md5", args[0].ToString())), nil
		}}),

		"sha1": runtime.FuncVal(&runtime.Function{Name: "sha1", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(hashString("sha1", args[0].ToString())), nil
		}}),

		"sha256": runtime.FuncVal(&runtime.Function{Name: "sha256", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(hashString("sha256", args[0].ToString())), nil
		}}),

		"sha512": runtime.FuncVal(&runtime.Function{Name: "sha512", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(hashString("sha512", args[0].ToString())), nil
		}}),

		"randomBytes": runtime.FuncVal(&runtime.Function{Name: "randomBytes", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			n := 16
			if len(args) > 0 {
				n = int(args[0].ToNumber())
			}
			b := make([]byte, n)
			rand.Read(b)
			return runtime.StringVal(hex.EncodeToString(b)), nil
		}}),

		"randomHex": runtime.FuncVal(&runtime.Function{Name: "randomHex", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			n := 16
			if len(args) > 0 {
				n = int(args[0].ToNumber())
			}
			b := make([]byte, n)
			rand.Read(b)
			return runtime.StringVal(hex.EncodeToString(b)), nil
		}}),

		"randomUUID": runtime.FuncVal(&runtime.Function{Name: "randomUUID", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			return runtime.StringVal(genUUID()), nil
		}}),

		"token": runtime.FuncVal(&runtime.Function{Name: "token", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			n := 32
			if len(args) > 0 {
				n = int(args[0].ToNumber())
			}
			b := make([]byte, n)
			rand.Read(b)
			return runtime.StringVal(hex.EncodeToString(b)), nil
		}}),

		"encrypt": runtime.FuncVal(&runtime.Function{Name: "encrypt", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) < 2 {
				return runtime.StringVal(""), nil
			}
			result, err := aesEncrypt(args[0].ToString(), args[1].ToString())
			if err != nil {
				return runtime.StringVal(""), err
			}
			return runtime.StringVal(result), nil
		}}),

		"decrypt": runtime.FuncVal(&runtime.Function{Name: "decrypt", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) < 2 {
				return runtime.StringVal(""), nil
			}
			result, err := aesDecrypt(args[0].ToString(), args[1].ToString())
			if err != nil {
				return runtime.Null, nil
			}
			return runtime.StringVal(result), nil
		}}),

		"toHex": runtime.FuncVal(&runtime.Function{Name: "toHex", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(hex.EncodeToString([]byte(args[0].ToString()))), nil
		}}),

		"fromHex": runtime.FuncVal(&runtime.Function{Name: "fromHex", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			b, err := hex.DecodeString(args[0].ToString())
			if err != nil {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(string(b)), nil
		}}),

		"base64Encode": runtime.FuncVal(&runtime.Function{Name: "base64Encode", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(base64.StdEncoding.EncodeToString([]byte(args[0].ToString()))), nil
		}}),

		"base64Decode": runtime.FuncVal(&runtime.Function{Name: "base64Decode", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			b, err := base64.StdEncoding.DecodeString(args[0].ToString())
			if err != nil {
				b, err = base64.RawStdEncoding.DecodeString(args[0].ToString())
				if err != nil {
					return runtime.StringVal(""), nil
				}
			}
			return runtime.StringVal(string(b)), nil
		}}),

		"base64UrlEncode": runtime.FuncVal(&runtime.Function{Name: "base64UrlEncode", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(base64.RawURLEncoding.EncodeToString([]byte(args[0].ToString()))), nil
		}}),

		"base64UrlDecode": runtime.FuncVal(&runtime.Function{Name: "base64UrlDecode", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			b, err := base64.RawURLEncoding.DecodeString(args[0].ToString())
			if err != nil {
				return runtime.StringVal(""), nil
			}
			return runtime.StringVal(string(b)), nil
		}}),

		"pbkdf2": runtime.FuncVal(&runtime.Function{Name: "pbkdf2", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) < 2 {
				return runtime.StringVal(""), nil
			}
			password := args[0].ToString()
			salt := args[1].ToString()
			iterations := 10000
			if len(args) > 2 {
				iterations = int(args[2].ToNumber())
			}
			return runtime.StringVal(simplePBKDF2(password, salt, iterations)), nil
		}}),

		"hashPassword": runtime.FuncVal(&runtime.Function{Name: "hashPassword", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) == 0 {
				return runtime.StringVal(""), nil
			}
			password := args[0].ToString()
			saltBytes := make([]byte, 16)
			rand.Read(saltBytes)
			salt := hex.EncodeToString(saltBytes)
			hash := simplePBKDF2(password, salt, 100000)
			return runtime.StringVal(salt + ":" + hash), nil
		}}),

		"verifyPassword": runtime.FuncVal(&runtime.Function{Name: "verifyPassword", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) < 2 {
				return runtime.False, nil
			}
			password := args[0].ToString()
			stored := args[1].ToString()
			parts := strings.SplitN(stored, ":", 2)
			if len(parts) != 2 {
				return runtime.False, nil
			}
			salt := parts[0]
			expectedHash := parts[1]
			actualHash := simplePBKDF2(password, salt, 100000)
			return runtime.BoolVal(actualHash == expectedHash), nil
		}}),

		"jwt": runtime.ObjectVal(map[string]*runtime.Value{
			"sign": runtime.FuncVal(&runtime.Function{Name: "sign", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
				if len(args) < 2 {
					return runtime.StringVal(""), fmt.Errorf("jwt.sign: payload and secret required")
				}
				payload := make(map[string]*runtime.Value)
				if args[0].Tag == runtime.TypeObject {
					for k, v := range args[0].ObjVal {
						payload[k] = v
					}
				}
				secret := args[1].ToString()
				expiresIn := int64(3600)
				if len(args) > 2 && args[2].Tag == runtime.TypeObject {
					if exp, ok := args[2].ObjVal["expiresIn"]; ok {
						expiresIn = int64(exp.ToNumber())
					}
					if exp, ok := args[2].ObjVal["expires"]; ok {
						expiresIn = int64(exp.ToNumber())
					}
				}
				return runtime.StringVal(jwtSign(payload, secret, expiresIn)), nil
			}}),
			"verify": runtime.FuncVal(&runtime.Function{Name: "verify", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
				if len(args) < 2 {
					return runtime.Null, fmt.Errorf("jwt.verify: token and secret required")
				}
				payload, err := jwtVerify(args[0].ToString(), args[1].ToString())
				if err != nil {
					return runtime.Null, err
				}
				return payload, nil
			}}),
			"decode": runtime.FuncVal(&runtime.Function{Name: "decode", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
				if len(args) == 0 {
					return runtime.Null, nil
				}
				parts := strings.Split(args[0].ToString(), ".")
				if len(parts) != 3 {
					return runtime.Null, nil
				}
				payloadBytes, err := base64.RawURLEncoding.DecodeString(parts[1])
				if err != nil {
					return runtime.Null, nil
				}
				return parseJSON(string(payloadBytes))
			}}),
		}),

		"compare": runtime.FuncVal(&runtime.Function{Name: "compare", Native: func(args []*runtime.Value, _ *runtime.Value) (*runtime.Value, error) {
			if len(args) < 2 {
				return runtime.False, nil
			}
			a := args[0].ToString()
			b := args[1].ToString()
			if len(a) != len(b) {
				return runtime.False, nil
			}
			result := 0
			for i := 0; i < len(a); i++ {
				result |= int(a[i]) ^ int(b[i])
			}
			return runtime.BoolVal(result == 0), nil
		}}),
	})
}
