// NTL lang
// Created by David Dev · GitHub: https://github.com/Megamexlevi2
// (c) David Dev 2026. License.

const std = @import("std");
const value = @import("../value.zig");
const Value = value.Value;

pub fn register(globals: *std.StringHashMap(Value)) !void {
    try globals.put("factorial", Value{ .native = factorial });
    try globals.put("fibonacci", Value{ .native = fibonacci });
    try globals.put("isPrime",   Value{ .native = isPrime   });
    try globals.put("clamp",     Value{ .native = clamp     });
    try globals.put("lerp",      Value{ .native = lerp      });
    try globals.put("randInt",   Value{ .native = randInt   });
}

fn factorial(args: []const Value) anyerror!Value {
    if (args.len == 0) return Value.One;
    var n = args[0].toInt();
    if (n < 0) n = 0;
    var result: i64 = 1;
    var i: i64 = 2;
    while (i <= n) : (i += 1) {
        result *%= i;
        if (i > 20) break;
    }
    return Value{ .int = result };
}

fn fibonacci(args: []const Value) anyerror!Value {
    if (args.len == 0) return Value.Zero;
    const n = args[0].toInt();
    if (n <= 0) return Value.Zero;
    if (n == 1) return Value.One;
    var a: i64 = 0;
    var b2: i64 = 1;
    var i: i64 = 2;
    while (i <= n) : (i += 1) {
        const tmp = a + b2;
        a = b2;
        b2 = tmp;
    }
    return Value{ .int = b2 };
}

fn isPrime(args: []const Value) anyerror!Value {
    if (args.len == 0) return Value.False;
    const n = args[0].toInt();
    if (n < 2) return Value.False;
    if (n == 2) return Value.True;
    if (@mod(n, 2) == 0) return Value.False;
    var i: i64 = 3;
    while (i * i <= n) : (i += 2) {
        if (@mod(n, i) == 0) return Value.False;
    }
    return Value.True;
}

fn clamp(args: []const Value) anyerror!Value {
    if (args.len < 3) return if (args.len > 0) args[0] else Value.Zero;
    const v   = args[0].toFloat();
    const lo  = args[1].toFloat();
    const hi  = args[2].toFloat();
    return Value{ .float = @max(lo, @min(hi, v)) };
}

fn lerp(args: []const Value) anyerror!Value {
    if (args.len < 3) return Value.Zero;
    const a  = args[0].toFloat();
    const b2 = args[1].toFloat();
    const t  = args[2].toFloat();
    return Value{ .float = a + (b2 - a) * t };
}

var rng_state: u64 = 0xDEADBEEFCAFEBABE;

fn randInt(args: []const Value) anyerror!Value {
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 7;
    rng_state ^= rng_state << 17;
    const r: i64 = @bitCast(rng_state >> 1);
    if (args.len >= 2) {
        const lo = args[0].toInt();
        const hi = args[1].toInt();
        if (hi > lo) return Value{ .int = lo + @mod(r, hi - lo) };
    }
    return Value{ .int = r };
}
