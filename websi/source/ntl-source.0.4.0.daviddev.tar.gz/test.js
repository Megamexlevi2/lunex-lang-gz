const start = Date.now()

let count = 0
let i = 0

while (i < 50000000) {
  count = count + i
  i = i + 1
}

const end = Date.now()

console.log("RESULT:", count)
console.log("TIME(ms):", end - start)