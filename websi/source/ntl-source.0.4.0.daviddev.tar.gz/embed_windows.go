//go:build windows

// NTL lang
// Created by David Dev · GitHub: https://github.com/Megamexlevi2
// (c) David Dev 2026. License.

package main

import _ "embed"

//go:embed bin/ntl-rt.exe
var embeddedZigRT []byte
